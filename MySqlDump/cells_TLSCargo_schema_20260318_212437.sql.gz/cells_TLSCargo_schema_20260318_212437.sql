/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cells_TLSCargo
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `event_time` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(64) NOT NULL,
  `entity_type` varchar(64) DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `extra_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_data`)),
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_user_time` (`user_id`,`event_time`),
  KEY `idx_audit_logs_type_time` (`event_type`,`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=12665 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cells`
--

DROP TABLE IF EXISTS `cells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cells` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `qr_payload` varchar(128) NOT NULL,
  `qr_file` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cells_code` (`code`),
  UNIQUE KEY `ux_cells_qr` (`qr_payload`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_dev_colibri_operation_flight_list`
--

DROP TABLE IF EXISTS `connector_dev_colibri_operation_flight_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_dev_colibri_operation_flight_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `flight_no` varchar(128) NOT NULL,
  `departure_at` datetime DEFAULT NULL,
  `departure_raw` varchar(128) NOT NULL DEFAULT '',
  `route` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(128) NOT NULL DEFAULT '',
  `external_id` varchar(128) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `flight_time` varchar(255) NOT NULL DEFAULT '',
  `carrier` varchar(128) NOT NULL DEFAULT '',
  `flight_number` varchar(128) NOT NULL DEFAULT '',
  `awb` varchar(128) NOT NULL DEFAULT '',
  `departure` varchar(128) NOT NULL DEFAULT '',
  `destination` varchar(128) NOT NULL DEFAULT '',
  `packages_count` int(11) DEFAULT NULL,
  `total_weight` decimal(12,3) DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `source_row_id` varchar(128) NOT NULL DEFAULT '',
  `containers_url` text DEFAULT NULL,
  `containers_json` longtext DEFAULT NULL,
  `containers_count` int(11) DEFAULT NULL,
  `containers_synced_at` datetime DEFAULT NULL,
  `containers_sync_status` varchar(32) NOT NULL DEFAULT 'pending',
  `containers_sync_error` text DEFAULT NULL,
  `raw_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_connector_flight_departure` (`connector_id`,`flight_no`,`departure_at`),
  KEY `idx_connector_external_id` (`connector_id`,`external_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_dev_colibri_operation_flight_list_containers`
--

DROP TABLE IF EXISTS `connector_dev_colibri_operation_flight_list_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_dev_colibri_operation_flight_list_containers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `flight_record_id` bigint(20) unsigned DEFAULT NULL,
  `flight_external_id` varchar(128) NOT NULL DEFAULT '',
  `flight_no` varchar(128) NOT NULL DEFAULT '',
  `container_external_id` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `flight` varchar(255) NOT NULL DEFAULT '',
  `departure` varchar(128) NOT NULL DEFAULT '',
  `destination` varchar(128) NOT NULL DEFAULT '',
  `awb` varchar(128) NOT NULL DEFAULT '',
  `packages_count` int(11) DEFAULT NULL,
  `total_weight` decimal(12,3) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `raw_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_connector_container` (`connector_id`,`container_external_id`),
  KEY `idx_connector_flight_external` (`connector_id`,`flight_external_id`),
  KEY `idx_connector_flight_record` (`connector_id`,`flight_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=980 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_operation_run_events`
--

DROP TABLE IF EXISTS `connector_operation_run_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_operation_run_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `run_id` varchar(96) NOT NULL,
  `connector_id` int(10) unsigned NOT NULL,
  `event_index` int(10) unsigned NOT NULL DEFAULT 0,
  `event_source` varchar(16) NOT NULL DEFAULT 'trace',
  `operation_id` varchar(96) NOT NULL DEFAULT '',
  `stage` varchar(96) NOT NULL DEFAULT '',
  `step_name` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `duration_ms` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `meta_json` longtext DEFAULT NULL,
  `event_time` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_run_event_index` (`run_id`,`event_index`),
  KEY `idx_connector_event_time` (`connector_id`,`event_time`),
  KEY `idx_operation_event_time` (`operation_id`,`event_time`),
  KEY `idx_status_event_time` (`status`,`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2669 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_operation_runs`
--

DROP TABLE IF EXISTS `connector_operation_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_operation_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `run_id` varchar(96) NOT NULL,
  `test_operation` varchar(64) NOT NULL DEFAULT 'report',
  `status` varchar(32) NOT NULL DEFAULT 'error',
  `message` text DEFAULT NULL,
  `target_table` varchar(128) NOT NULL DEFAULT '',
  `started_at` datetime NOT NULL,
  `finished_at` datetime NOT NULL,
  `duration_ms` int(10) unsigned NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `trace_log_json` longtext DEFAULT NULL,
  `step_log_json` longtext DEFAULT NULL,
  `execution_plan_json` longtext DEFAULT NULL,
  `chain_status_json` longtext DEFAULT NULL,
  `artifacts_dir` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_run_id` (`run_id`),
  KEY `idx_connector_created` (`connector_id`,`created_at`),
  KEY `idx_connector_status_created` (`connector_id`,`status`,`created_at`),
  KEY `idx_test_operation_created` (`test_operation`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_report_colibri_az`
--

DROP TABLE IF EXISTS `connector_report_colibri_az`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_report_colibri_az` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `period_from` date DEFAULT NULL,
  `period_to` date DEFAULT NULL,
  `payload_json` longtext DEFAULT NULL,
  `source_file` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_connector_period` (`connector_id`,`period_from`,`period_to`)
) ENGINE=InnoDB AUTO_INCREMENT=2960 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connector_report_dev_colibri_az`
--

DROP TABLE IF EXISTS `connector_report_dev_colibri_az`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connector_report_dev_colibri_az` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `period_from` date DEFAULT NULL,
  `period_to` date DEFAULT NULL,
  `payload_json` longtext DEFAULT NULL,
  `source_file` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_connector_period` (`connector_id`,`period_from`,`period_to`)
) ENGINE=InnoDB AUTO_INCREMENT=68466 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connectors`
--

DROP TABLE IF EXISTS `connectors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connectors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `countries` varchar(255) NOT NULL DEFAULT '',
  `base_url` varchar(255) NOT NULL DEFAULT '',
  `auth_type` varchar(32) NOT NULL DEFAULT 'login',
  `auth_username` varchar(128) NOT NULL DEFAULT '',
  `auth_password` varchar(255) NOT NULL DEFAULT '',
  `api_token` varchar(255) NOT NULL DEFAULT '',
  `auth_token` text DEFAULT NULL,
  `auth_token_expires_at` datetime DEFAULT NULL,
  `auth_cookies` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_sync_at` datetime DEFAULT NULL,
  `last_success_at` datetime DEFAULT NULL,
  `last_error` text DEFAULT NULL,
  `ssl_ignore` tinyint(1) NOT NULL DEFAULT 0,
  `scenario_json` text DEFAULT NULL,
  `operations_json` longtext DEFAULT NULL,
  `last_manual_confirm_at` datetime DEFAULT NULL,
  `last_manual_confirm_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_test_connector` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connectors_addons`
--

DROP TABLE IF EXISTS `connectors_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connectors_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connector_id` int(10) unsigned NOT NULL,
  `connector_name` varchar(128) NOT NULL DEFAULT '',
  `addons_json` longtext DEFAULT NULL,
  `node_mapping_json` longtext DEFAULT NULL,
  `status_targets_json` longtext DEFAULT NULL,
  `report_out_statuses_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_connector_id` (`connector_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_countries`
--

DROP TABLE IF EXISTS `dest_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code_iso2` char(3) NOT NULL,
  `code_iso3` char(3) NOT NULL,
  `name_en` varchar(128) NOT NULL,
  `name_local` varchar(128) NOT NULL,
  `aliases` text DEFAULT NULL,
  `forwarders_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`forwarders_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dest_countries_iso2` (`code_iso2`),
  UNIQUE KEY `ux_dest_countries_iso3` (`code_iso3`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_countries.bkp`
--

DROP TABLE IF EXISTS `dest_countries.bkp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_countries.bkp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code_iso2` char(2) NOT NULL,
  `code_iso3` char(3) NOT NULL,
  `name_en` varchar(128) NOT NULL,
  `name_local` varchar(128) NOT NULL,
  `aliases` text DEFAULT NULL,
  `forwarders_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`forwarders_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dest_countries_iso2` (`code_iso2`),
  UNIQUE KEY `ux_dest_countries_iso3` (`code_iso3`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_country_aliases`
--

DROP TABLE IF EXISTS `dest_country_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_country_aliases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` bigint(20) unsigned NOT NULL,
  `alias` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_alias` (`alias`),
  KEY `fk_alias_country` (`country_id`),
  CONSTRAINT `fk_alias_country` FOREIGN KEY (`country_id`) REFERENCES `dest_countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `device_uid` varchar(64) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `serial` varchar(128) DEFAULT NULL,
  `model` varchar(128) DEFAULT NULL,
  `app_version` varchar(32) DEFAULT NULL,
  `device_token` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `last_seen_at` datetime(6) DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `activated_at` datetime(6) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_uid` (`device_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_groups`
--

DROP TABLE IF EXISTS `menu_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_groups` (
  `code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) NOT NULL DEFAULT 'bi bi-circle',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_key` varchar(64) NOT NULL,
  `group_code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) NOT NULL DEFAULT 'bi bi-circle',
  `action` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_key` (`menu_key`),
  KEY `fk_menu_items_group` (`group_code`),
  CONSTRAINT `fk_menu_items_group` FOREIGN KEY (`group_code`) REFERENCES `menu_groups` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ocr_carrier_templates`
--

DROP TABLE IF EXISTS `ocr_carrier_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ocr_carrier_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `carrier_code` varchar(32) NOT NULL,
  `carrier_name` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 100,
  `match_keywords` text DEFAULT NULL,
  `template_json` longtext NOT NULL CHECK (json_valid(`template_json`)),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_carrier_code` (`carrier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL COMMENT 'Уникальный код права, например warehouse. stock. manage',
  `name` varchar(255) NOT NULL COMMENT 'Человекочитаемое название',
  `description` text DEFAULT NULL COMMENT 'Описание права',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_menu`
--

DROP TABLE IF EXISTS `role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `menu_key` varchar(64) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_uk` (`role_code`,`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_code` varchar(50) NOT NULL COMMENT 'Код роли:  ADMIN, WORKER, ANALYST и т.д.',
  `permission_code` varchar(100) NOT NULL COMMENT 'Код права из таблицы permissions',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_perm` (`role_code`,`permission_code`),
  KEY `idx_role` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_task_runs`
--

DROP TABLE IF EXISTS `system_task_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_task_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `finished_at` datetime DEFAULT NULL,
  `status` varchar(16) NOT NULL,
  `message` text DEFAULT NULL,
  `context_json` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_started` (`task_id`,`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=9526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_tasks`
--

DROP TABLE IF EXISTS `system_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `endpoint_action` varchar(128) NOT NULL,
  `payload_json` longtext DEFAULT NULL,
  `interval_minutes` int(10) unsigned NOT NULL DEFAULT 60,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_run_at` datetime DEFAULT NULL,
  `next_run_at` datetime DEFAULT NULL,
  `last_status` varchar(16) DEFAULT NULL,
  `last_message` text DEFAULT NULL,
  `is_running` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=88148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tool_resources`
--

DROP TABLE IF EXISTS `tool_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tool_resources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` char(36) NOT NULL COMMENT 'UUID for QR generation and lookups',
  `name` varchar(255) NOT NULL COMMENT 'Tool name or model',
  `serial_number` varchar(255) NOT NULL COMMENT 'Manufacturer serial number',
  `price_buy` decimal(12,2) unsigned DEFAULT NULL,
  `warranty_days` int(10) unsigned NOT NULL DEFAULT 0,
  `warranty_until` date GENERATED ALWAYS AS (case when `warranty_days` = 0 or `purchase_date` is null then NULL else `purchase_date` + interval `warranty_days` day end) STORED,
  `purchase_date` date NOT NULL COMMENT 'Date the tool was purchased',
  `registered_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Date the tool was registered in the system',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `location` varchar(255) NOT NULL COMMENT 'Storage or active use location',
  `assigned_user_id` bigint(20) unsigned DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `passport_service_months` smallint(5) unsigned NOT NULL COMMENT 'Passport service life in months (e.g., 24 months for 2 years)',
  `resource_days` int(10) unsigned NOT NULL DEFAULT 0,
  `actual_usage_days` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Total days counted as in-use (time accumulates whenever the tool is not in warehouse state)',
  `operational_until` date DEFAULT NULL,
  `status` enum('active','inactive','decommissioned') NOT NULL DEFAULT 'active' COMMENT 'Current lifecycle status of the tool',
  `qr_path` text NOT NULL,
  `img_path` text NOT NULL,
  `notes` text DEFAULT NULL COMMENT 'Optional administrative notes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  UNIQUE KEY `serial_number` (`serial_number`),
  KEY `idx_tool_resources_registered_status` (`registered_at`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `ui_lang` varchar(5) NOT NULL DEFAULT 'uk',
  `ui_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ui_settings`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `last_login_at` datetime(6) DEFAULT NULL,
  `login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `last_user_agent` text DEFAULT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'USER',
  `qr_login_token` varchar(128) DEFAULT NULL,
  `qr_login_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_in`
--

DROP TABLE IF EXISTS `warehouse_item_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_in` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `committed` tinyint(1) NOT NULL DEFAULT 0,
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `cell_id` int(11) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `addons_json` longtext DEFAULT NULL,
  `ocr_raw_text` mediumtext DEFAULT NULL,
  `ocr_engine` varchar(32) DEFAULT NULL,
  `ocr_confidence` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batch_user_committed` (`batch_uid`,`user_id`,`committed`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_out`
--

DROP TABLE IF EXISTS `warehouse_item_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_out` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `committed` tinyint(1) NOT NULL DEFAULT 0,
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `stock_item_id` bigint(20) unsigned NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'for_sync',
  `status_message` text DEFAULT NULL,
  `status_updated_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock_item_id` (`stock_item_id`),
  KEY `idx_batch_user_committed` (`batch_uid`,`user_id`,`committed`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_created` (`created_at`),
  KEY `idx_status_updated` (`status`,`status_updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7341 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_stock`
--

DROP TABLE IF EXISTS `warehouse_item_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_stock` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `cell_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `addons_json` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batch_uid` (`batch_uid`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_cell_id` (`cell_id`),
  CONSTRAINT `fk_item_stock_cell` FOREIGN KEY (`cell_id`) REFERENCES `cells` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_sync_audit`
--

DROP TABLE IF EXISTS `warehouse_sync_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_sync_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `tracking_no` varchar(255) NOT NULL DEFAULT '',
  `forwarder` varchar(120) NOT NULL DEFAULT '',
  `country_code` varchar(16) NOT NULL DEFAULT '',
  `status` varchar(20) NOT NULL DEFAULT 'error',
  `message` text DEFAULT NULL,
  `response_json` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item_created` (`item_id`,`created_at`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8878 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_sync_batch_job_items`
--

DROP TABLE IF EXISTS `warehouse_sync_batch_job_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_sync_batch_job_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `connector_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `message` text DEFAULT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_job_item` (`job_id`,`item_id`),
  KEY `idx_job_status` (`job_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8824 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_sync_batch_jobs`
--

DROP TABLE IF EXISTS `warehouse_sync_batch_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_sync_batch_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(16) NOT NULL DEFAULT 'queued',
  `forwarder` varchar(64) DEFAULT NULL,
  `requested_by` int(10) unsigned DEFAULT NULL,
  `total_items` int(10) unsigned NOT NULL DEFAULT 0,
  `processed_items` int(10) unsigned NOT NULL DEFAULT 0,
  `ok_items` int(10) unsigned NOT NULL DEFAULT 0,
  `fail_items` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3862 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_sync_trace`
--

DROP TABLE IF EXISTS `warehouse_sync_trace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_sync_trace` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `connector_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `job_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `stage` varchar(64) NOT NULL DEFAULT '',
  `policy_code` varchar(64) NOT NULL DEFAULT '',
  `decision` varchar(32) NOT NULL DEFAULT '',
  `reason` text DEFAULT NULL,
  `snapshot_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item_created` (`item_id`,`created_at`),
  KEY `idx_connector_created` (`connector_id`,`created_at`),
  KEY `idx_job_created` (`job_id`,`created_at`),
  KEY `idx_stage_created` (`stage`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=42171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'cells_TLSCargo'
--

--
-- Dumping routines for database 'cells_TLSCargo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-18 21:24:37
