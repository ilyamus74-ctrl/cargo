/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cells_TLSCargo
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `event_time` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(64) NOT NULL,
  `entity_type` varchar(64) DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `extra_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_data`)),
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_user_time` (`user_id`,`event_time`),
  KEY `idx_audit_logs_type_time` (`event_type`,`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cells`
--

DROP TABLE IF EXISTS `cells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cells` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `qr_payload` varchar(128) NOT NULL,
  `qr_file` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cells_code` (`code`),
  UNIQUE KEY `ux_cells_qr` (`qr_payload`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_countries`
--

DROP TABLE IF EXISTS `dest_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code_iso2` char(3) NOT NULL,
  `code_iso3` char(3) NOT NULL,
  `name_en` varchar(128) NOT NULL,
  `name_local` varchar(128) NOT NULL,
  `aliases` text DEFAULT NULL,
  `forwarders_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`forwarders_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dest_countries_iso2` (`code_iso2`),
  UNIQUE KEY `ux_dest_countries_iso3` (`code_iso3`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_countries.bkp`
--

DROP TABLE IF EXISTS `dest_countries.bkp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_countries.bkp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code_iso2` char(2) NOT NULL,
  `code_iso3` char(3) NOT NULL,
  `name_en` varchar(128) NOT NULL,
  `name_local` varchar(128) NOT NULL,
  `aliases` text DEFAULT NULL,
  `forwarders_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`forwarders_json`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dest_countries_iso2` (`code_iso2`),
  UNIQUE KEY `ux_dest_countries_iso3` (`code_iso3`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dest_country_aliases`
--

DROP TABLE IF EXISTS `dest_country_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dest_country_aliases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` bigint(20) unsigned NOT NULL,
  `alias` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_alias` (`alias`),
  KEY `fk_alias_country` (`country_id`),
  CONSTRAINT `fk_alias_country` FOREIGN KEY (`country_id`) REFERENCES `dest_countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `device_uid` varchar(64) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `serial` varchar(128) DEFAULT NULL,
  `model` varchar(128) DEFAULT NULL,
  `app_version` varchar(32) DEFAULT NULL,
  `device_token` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `last_seen_at` datetime(6) DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `activated_at` datetime(6) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_uid` (`device_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_groups`
--

DROP TABLE IF EXISTS `menu_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_groups` (
  `code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) NOT NULL DEFAULT 'bi bi-circle',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_key` varchar(64) NOT NULL,
  `group_code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) NOT NULL DEFAULT 'bi bi-circle',
  `action` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_key` (`menu_key`),
  KEY `fk_menu_items_group` (`group_code`),
  CONSTRAINT `fk_menu_items_group` FOREIGN KEY (`group_code`) REFERENCES `menu_groups` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ocr_carrier_templates`
--

DROP TABLE IF EXISTS `ocr_carrier_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ocr_carrier_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `carrier_code` varchar(32) NOT NULL,
  `carrier_name` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 100,
  `match_keywords` text DEFAULT NULL,
  `template_json` longtext NOT NULL CHECK (json_valid(`template_json`)),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_carrier_code` (`carrier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_menu`
--

DROP TABLE IF EXISTS `role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `menu_key` varchar(64) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_menu_uk` (`role_code`,`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tool_resources`
--

DROP TABLE IF EXISTS `tool_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tool_resources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` char(36) NOT NULL COMMENT 'UUID for QR generation and lookups',
  `name` varchar(255) NOT NULL COMMENT 'Tool name or model',
  `serial_number` varchar(255) NOT NULL COMMENT 'Manufacturer serial number',
  `price_buy` decimal(12,2) unsigned DEFAULT NULL,
  `warranty_days` int(10) unsigned NOT NULL DEFAULT 0,
  `warranty_until` date GENERATED ALWAYS AS (case when `warranty_days` = 0 or `purchase_date` is null then NULL else `purchase_date` + interval `warranty_days` day end) STORED,
  `purchase_date` date NOT NULL COMMENT 'Date the tool was purchased',
  `registered_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Date the tool was registered in the system',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `location` varchar(255) NOT NULL COMMENT 'Storage or active use location',
  `assigned_user_id` bigint(20) unsigned DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `passport_service_months` smallint(5) unsigned NOT NULL COMMENT 'Passport service life in months (e.g., 24 months for 2 years)',
  `resource_days` int(10) unsigned NOT NULL DEFAULT 0,
  `actual_usage_days` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Total days counted as in-use (time accumulates whenever the tool is not in warehouse state)',
  `operational_until` date DEFAULT NULL,
  `status` enum('active','inactive','decommissioned') NOT NULL DEFAULT 'active' COMMENT 'Current lifecycle status of the tool',
  `qr_path` text NOT NULL,
  `img_path` text NOT NULL,
  `notes` text DEFAULT NULL COMMENT 'Optional administrative notes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  UNIQUE KEY `serial_number` (`serial_number`),
  KEY `idx_tool_resources_registered_status` (`registered_at`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned NOT NULL,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `ui_lang` varchar(5) NOT NULL DEFAULT 'uk',
  `ui_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ui_settings`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `last_login_at` datetime(6) DEFAULT NULL,
  `login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `last_user_agent` text DEFAULT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'USER',
  `qr_login_token` varchar(128) DEFAULT NULL,
  `qr_login_enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_in`
--

DROP TABLE IF EXISTS `warehouse_item_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_in` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `committed` tinyint(1) NOT NULL DEFAULT 0,
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `ocr_raw_text` mediumtext DEFAULT NULL,
  `ocr_engine` varchar(32) DEFAULT NULL,
  `ocr_confidence` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batch_user_committed` (`batch_uid`,`user_id`,`committed`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_out`
--

DROP TABLE IF EXISTS `warehouse_item_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_out` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `committed` tinyint(1) NOT NULL DEFAULT 0,
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batch_user_committed` (`batch_uid`,`user_id`,`committed`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warehouse_item_stock`
--

DROP TABLE IF EXISTS `warehouse_item_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse_item_stock` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batch_uid` bigint(20) unsigned NOT NULL,
  `uid_created` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `cell_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `tuid` varchar(64) NOT NULL,
  `tracking_no` varchar(64) NOT NULL,
  `carrier_code` varchar(32) DEFAULT NULL,
  `carrier_name` varchar(64) DEFAULT NULL,
  `receiver_country_code` varchar(2) DEFAULT NULL,
  `receiver_country_name` varchar(64) DEFAULT NULL,
  `receiver_name` varchar(128) DEFAULT NULL,
  `receiver_company` varchar(128) DEFAULT NULL,
  `receiver_address` varchar(255) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender_company` varchar(128) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT NULL,
  `size_l_cm` decimal(10,1) DEFAULT NULL,
  `size_w_cm` decimal(10,1) DEFAULT NULL,
  `size_h_cm` decimal(10,1) DEFAULT NULL,
  `label_image` varchar(255) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_batch_uid` (`batch_uid`),
  KEY `idx_tuid` (`tuid`),
  KEY `idx_cell_id` (`cell_id`),
  CONSTRAINT `fk_item_stock_cell` FOREIGN KEY (`cell_id`) REFERENCES `cells` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'cells_TLSCargo'
--

--
-- Dumping routines for database 'cells_TLSCargo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-16 15:51:16
