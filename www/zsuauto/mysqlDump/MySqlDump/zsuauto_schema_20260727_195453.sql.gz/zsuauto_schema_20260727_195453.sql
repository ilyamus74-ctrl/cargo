/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: zsuauto
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zs_adminusers`
--

DROP TABLE IF EXISTS `zs_adminusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_adminusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `city` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create` date NOT NULL,
  `last_enter` datetime NOT NULL,
  `count` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `desc` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_announce_auto`
--

DROP TABLE IF EXISTS `zs_announce_auto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_announce_auto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_announce` int(11) DEFAULT NULL,
  `id_lang` int(11) DEFAULT NULL,
  `id_country` varchar(11) DEFAULT NULL,
  `name_announce` varchar(5000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `url_announce` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `short_text_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `text_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `text_full_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `img_announce` varchar(10000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `img_dir` varchar(50) DEFAULT NULL,
  `img_thumb` varchar(100) DEFAULT NULL,
  `date_in_announce` datetime DEFAULT NULL,
  `id_wp` int(11) DEFAULT NULL,
  `location` varchar(250) DEFAULT NULL,
  `active_announce` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `marke` varchar(50) DEFAULT NULL,
  `modell` varchar(50) DEFAULT NULL,
  `kilometerstand` varchar(50) DEFAULT NULL,
  `fahrzeugzustand` varchar(50) DEFAULT NULL,
  `erstzulassung` varchar(50) DEFAULT NULL,
  `kraftstoffart` varchar(50) DEFAULT NULL,
  `Leistung` varchar(50) DEFAULT NULL,
  `Getriebe` varchar(50) DEFAULT NULL,
  `fahrzeugtyp` varchar(50) DEFAULT NULL,
  `anzahl_turen` varchar(50) DEFAULT NULL,
  `hu_bis` varchar(50) DEFAULT NULL,
  `umweltplakette` varchar(50) DEFAULT NULL,
  `schadstoffklasse` varchar(50) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `farbe` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url_news` (`url_announce`(255)),
  KEY `id` (`id`),
  KEY `img_dir` (`img_dir`)
) ENGINE=MyISAM AUTO_INCREMENT=8231 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_announce_auto_uk`
--

DROP TABLE IF EXISTS `zs_announce_auto_uk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_announce_auto_uk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_announce` int(11) DEFAULT NULL,
  `id_lang` int(11) DEFAULT NULL,
  `id_country` varchar(11) DEFAULT NULL,
  `name_announce` varchar(5000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `url_announce` varchar(2000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `short_text_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `text_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `text_full_announce` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `img_announce` varchar(10000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `img_dir` varchar(50) DEFAULT NULL,
  `img_thumb` varchar(100) DEFAULT NULL,
  `date_in_announce` datetime DEFAULT NULL,
  `id_wp` int(11) DEFAULT NULL,
  `location` varchar(250) DEFAULT NULL,
  `active_announce` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `marke` varchar(50) DEFAULT NULL,
  `modell` varchar(50) DEFAULT NULL,
  `kilometerstand` varchar(50) DEFAULT NULL,
  `fahrzeugzustand` varchar(50) DEFAULT NULL,
  `erstzulassung` varchar(50) DEFAULT NULL,
  `kraftstoffart` varchar(50) DEFAULT NULL,
  `Leistung` varchar(50) DEFAULT NULL,
  `Getriebe` varchar(50) DEFAULT NULL,
  `fahrzeugtyp` varchar(50) DEFAULT NULL,
  `anzahl_turen` varchar(50) DEFAULT NULL,
  `hu_bis` varchar(50) DEFAULT NULL,
  `umweltplakette` varchar(50) DEFAULT NULL,
  `schadstoffklasse` varchar(50) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `farbe` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url_news` (`url_announce`(255)),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2045 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_preg_auto`
--

DROP TABLE IF EXISTS `zs_preg_auto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_preg_auto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_wp` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `main_url` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `url` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `date_in` datetime NOT NULL,
  `preg_count_url` varchar(255) NOT NULL,
  `preg_link` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_link_some` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_name` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_anonce` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_full_announce` varchar(250) NOT NULL,
  `preg_price` varchar(250) NOT NULL,
  `preg_location` varchar(250) NOT NULL,
  `preg_img` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_f_img` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_video` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `active` int(11) NOT NULL,
  `rss` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `charset` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `preg_marke` varchar(250) NOT NULL,
  `preg_modell` varchar(250) NOT NULL,
  `preg_kilometerstand` varchar(250) NOT NULL,
  `preg_fahrzeugzustand` varchar(250) NOT NULL,
  `preg_erstzulassung` varchar(250) NOT NULL,
  `preg_kraftstoffart` varchar(250) NOT NULL,
  `preg_Leistung` varchar(250) NOT NULL,
  `preg_Getriebe` varchar(250) NOT NULL,
  `preg_fahrzeugtyp` varchar(250) NOT NULL,
  `preg_anzahl_turen` varchar(250) NOT NULL,
  `preg_hu_bis` varchar(250) NOT NULL,
  `preg_umweltplakette` varchar(250) NOT NULL,
  `preg_schadstoffklasse` varchar(250) NOT NULL,
  `preg_farbe` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_request_cases`
--

DROP TABLE IF EXISTS `zs_request_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_request_cases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `public_token` varchar(64) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_zs_request_cases_request_id` (`request_id`),
  UNIQUE KEY `ux_zs_request_cases_public_token` (`public_token`),
  KEY `idx_zs_request_cases_created_by` (`created_by`),
  KEY `idx_zs_request_cases_active` (`is_active`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_request_entries`
--

DROP TABLE IF EXISTS `zs_request_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_request_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `author_admin_id` int(11) NOT NULL,
  `entry_text` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zs_request_entries_case_created` (`case_id`,`created_at`),
  KEY `idx_zs_request_entries_author` (`author_admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_request_files`
--

DROP TABLE IF EXISTS `zs_request_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_request_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `file_type` enum('image','video','document') NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `relative_path` varchar(500) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zs_request_files_entry` (`entry_id`),
  KEY `idx_zs_request_files_type` (`file_type`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zs_requests`
--

DROP TABLE IF EXISTS `zs_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zs_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lotImgDir` varchar(100) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `remark` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'zsuauto'
--

--
-- Dumping routines for database 'zsuauto'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-27 19:54:53
